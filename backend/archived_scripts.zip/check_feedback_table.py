from sqlalchemy import create_engine, text
PROD_DB = "os.getenv('DATABASE_URL', 'sqlite:///aura.db')"
engine = create_engine(PROD_DB)
with engine.connect() as conn:
    cols = conn.execute(text("SELECT column_name FROM information_schema.columns WHERE table_name='feedback' ORDER BY ordinal_position")).fetchall()
    print("feedback columns:", [c[0] for c in cols])
